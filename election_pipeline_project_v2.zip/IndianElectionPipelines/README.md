# IndianElectionPipelines

Functionality-first AWS pipeline: S3 raw PDF -> EventBridge -> Step Functions -> Docker Lambda -> S3 raw CSV -> Glue cleaning -> S3 cleaned Parquet -> Glue normalization -> Redshift Serverless.

## Layout
- `infra/pipeline_stack.py`: three buckets, event trigger, Lambda, two Glue jobs, Step Functions, Redshift Serverless
- `lambda/extractor.py`: adapted from user-provided West Bengal election PDF extractor
- `lambda/handler.py`: S3 download, CSV generation and S3 upload
- `glue/cleaning.py`: basic schema, validation, rejected records and Parquet
- `glue/normalization.py`: five analytical datasets and Redshift COPY + election-scope replacement

## Deploy
1. Configure AWS credentials and region (default `ap-south-1`).
2. Install Python dependencies: `python -m pip install -r requirements.txt`.
3. Install AWS CDK CLI (`npm install -g aws-cdk`) and Docker.
4. Run `cdk bootstrap` once, then `cdk synth`, then `cdk deploy`.
5. Upload a compatible PDF to `s3://<RawPdfBucket>/raw/assembly/west_bengal/1951/1951.pdf`.
6. Check the Step Functions execution and the Redshift `analytics` schema.

**Caution:** Redshift Serverless incurs charges. This template creates a workgroup; destroy it when no longer needed. Buckets use RETAIN.

## Constraints / current scope
- Parser is supplied for West Bengal Assembly reports and is not validated for arbitrary states or years.
- Only `candidate_ballots.csv` is emitted by Lambda; its columns match the supplied source extractor.
- Cleaned data and normalized datasets are Parquet, not CSV.
- Advanced retries, DLQ, alerting, IAM tightening, concurrency locks and CI/CD are intentionally deferred.
- Re-running the same election replaces its rows in each Redshift table; parallel runs of the same election are **not** safe yet.
- Redshift COPY/SQL behavior and AWS CDK synthesis must be validated in an AWS environment; no deployment has been performed.
- The sample extractor has not been validated against an actual election PDF in this package.
