#!/usr/bin/env python3
import aws_cdk as cdk
from infra.pipeline_stack import ElectionPipelineStack

app = cdk.App()
ElectionPipelineStack(app, 'ElectionPipelineStack', env=cdk.Environment(account=__import__('os').environ.get('CDK_DEFAULT_ACCOUNT'), region=__import__('os').environ.get('CDK_DEFAULT_REGION', 'ap-south-1')))
app.synth()
