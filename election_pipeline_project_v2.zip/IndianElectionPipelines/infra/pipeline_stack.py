from aws_cdk import (
    Stack, Aws, Duration, RemovalPolicy, Size, CfnOutput,
    aws_s3 as s3, aws_lambda as lambda_, aws_iam as iam,
    aws_events as events, aws_events_targets as targets,
    aws_stepfunctions as sfn, aws_stepfunctions_tasks as tasks,
    aws_glue as glue, aws_s3_assets as assets,
    aws_redshiftserverless as redshift,
)
from constructs import Construct


class ElectionPipelineStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs):
        super().__init__(scope, construct_id, **kwargs)
        prefix = f'election-{Aws.ACCOUNT_ID}-{Aws.REGION}'

        def bucket(name: str) -> s3.Bucket:
            return s3.Bucket(self, name, bucket_name=f'{prefix}-{name.lower()}',
                block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
                enforce_ssl=True, encryption=s3.BucketEncryption.S3_MANAGED,
                versioned=True, removal_policy=RemovalPolicy.RETAIN,
                event_bridge_enabled=name == 'RawPdf')

        raw_pdf = bucket('RawPdf')
        raw_csv = bucket('RawCsv')
        processed = bucket('ProcessedData')

        extractor = lambda_.DockerImageFunction(self, 'ElectionPdfExtractor',
            function_name=f'{prefix}-pdf-extractor',
            code=lambda_.DockerImageCode.from_image_asset('lambda'),
            architecture=lambda_.Architecture.X86_64,
            memory_size=2048, ephemeral_storage_size=Size.mebibytes(4096),
            timeout=Duration.minutes(15),
            environment={'RAW_CSV_BUCKET': raw_csv.bucket_name, 'PROCESSED_BUCKET': processed.bucket_name})
        raw_pdf.grant_read(extractor)
        raw_csv.grant_put(extractor)

        scripts = {}
        for name in ('cleaning', 'normalization'):
            asset = assets.Asset(self, f'{name.title()}Script', path=f'glue/{name}.py')
            scripts[name] = asset

        glue_role = iam.Role(self, 'ElectionGlueRole', assumed_by=iam.ServicePrincipal('glue.amazonaws.com'))
        glue_role.add_managed_policy(iam.ManagedPolicy.from_aws_managed_policy_name('service-role/AWSGlueServiceRole'))
        raw_csv.grant_read(glue_role)
        processed.grant_read_write(glue_role)
        for asset in scripts.values():
            asset.grant_read(glue_role)

        namespace = redshift.CfnNamespace(self, 'ElectionWarehouseNamespace',
            namespace_name=f'election-{Aws.ACCOUNT_ID}-{Aws.REGION}',
            db_name='elections', manage_admin_password=True)
        workgroup = redshift.CfnWorkgroup(self, 'ElectionWarehouseWorkgroup',
            workgroup_name=f'election-{Aws.ACCOUNT_ID}-{Aws.REGION}',
            namespace_name=namespace.namespace_name,
            publicly_accessible=False, base_capacity=8)
        workgroup.add_dependency(namespace)
        redshift_role = iam.Role(self, 'ElectionRedshiftS3Role',
            assumed_by=iam.ServicePrincipal('redshift.amazonaws.com'))
        processed.grant_read(redshift_role)
        # Redshift COPY requires the namespace to have this IAM role associated.
        namespace.iam_roles = [redshift_role.role_arn]
        namespace.default_iam_role_arn = redshift_role.role_arn
        glue_role.add_to_policy(iam.PolicyStatement(actions=['redshift-data:ExecuteStatement', 'redshift-data:BatchExecuteStatement', 'redshift-data:DescribeStatement', 'redshift-data:GetStatementResult', 'redshift-serverless:GetCredentials'], resources=['*']))

        jobs = {}
        for name, script in scripts.items():
            args = {'--job-language': 'python', '--enable-job-insights': 'false', '--RAW_CSV_BUCKET': raw_csv.bucket_name,
                    '--PROCESSED_BUCKET': processed.bucket_name}
            if name == 'normalization':
                args.update({'--REDSHIFT_WORKGROUP': workgroup.workgroup_name,
                             '--REDSHIFT_DATABASE': 'elections', '--REDSHIFT_ROLE_ARN': redshift_role.role_arn})
            jobs[name] = glue.CfnJob(self, f'Election{name.title()}Job',
                name=f'{prefix}-{name}', role=glue_role.role_arn,
                glue_version='5.0', worker_type='G.1X', number_of_workers=2,
                command=glue.CfnJob.JobCommandProperty(name='glueetl', python_version='3',
                    script_location=f's3://{script.s3_bucket_name}/{script.s3_object_key}'),
                default_arguments=args)

        extract = tasks.LambdaInvoke(self, 'ExtractPdf', lambda_function=extractor,
            payload=sfn.TaskInput.from_object({'bucket': sfn.JsonPath.string_at('$.detail.bucket.name'),
                                                 'key': sfn.JsonPath.string_at('$.detail.object.key'),
                                                 'execution_id': sfn.JsonPath.string_at('$$.Execution.Name')}),
            payload_response_only=True, result_path='$.extract')
        clean = tasks.GlueStartJobRun(self, 'CleanCandidateBallots',
            glue_job_name=jobs['cleaning'].name, integration_pattern=sfn.IntegrationPattern.RUN_JOB,
            arguments=sfn.TaskInput.from_object({
                '--INPUT_URI': sfn.JsonPath.string_at('$.extract.csv_uri'),
                '--EXECUTION_ID': sfn.JsonPath.string_at('$.extract.execution_id'),
                '--OUTPUT_PREFIX': sfn.JsonPath.string_at('$.extract.cleaned_prefix')}),
            result_path='$.clean_job')
        normalize = tasks.GlueStartJobRun(self, 'NormalizeAndLoadRedshift',
            glue_job_name=jobs['normalization'].name, integration_pattern=sfn.IntegrationPattern.RUN_JOB,
            arguments=sfn.TaskInput.from_object({
                '--INPUT_PREFIX': sfn.JsonPath.string_at('$.extract.cleaned_prefix'),
                '--EXECUTION_ID': sfn.JsonPath.string_at('$.extract.execution_id'),
                '--OUTPUT_PREFIX': sfn.JsonPath.string_at('$.extract.warehouse_prefix')}),
            result_path='$.warehouse_job')
        clean.node.add_dependency(jobs['cleaning'])
        normalize.node.add_dependency(jobs['normalization'])
        state_machine = sfn.StateMachine(self, 'ElectionProcessingStateMachine',
            state_machine_name=f'{prefix}-processing',
            definition_body=sfn.DefinitionBody.from_chainable(extract.next(clean).next(normalize)),
            timeout=Duration.hours(3))
        rule = events.Rule(self, 'ElectionPdfUploadRule',
            event_pattern=events.EventPattern(source=['aws.s3'], detail_type=['Object Created'],
                detail={'bucket': {'name': [raw_pdf.bucket_name]}, 'object': {'key': [{'prefix': 'raw/'}]}}))
        rule.add_target(targets.SfnStateMachine(state_machine))
        for name, resource in [('RawPdfBucket',raw_pdf), ('RawCsvBucket',raw_csv), ('ProcessedDataBucket',processed)]:
            CfnOutput(self, name, value=resource.bucket_name)
        CfnOutput(self, 'StateMachineArn', value=state_machine.state_machine_arn)
        CfnOutput(self, 'RedshiftWorkgroup', value=workgroup.workgroup_name)
