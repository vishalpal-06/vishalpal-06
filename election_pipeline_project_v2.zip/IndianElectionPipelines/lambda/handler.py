import json
import os
import re
import tempfile
from pathlib import Path
from urllib.parse import unquote_plus
import boto3
from extractor import main as unused_cli_main, extract_pdf, write_denormalized
from collections import defaultdict

s3 = boto3.client('s3')


def handler(event, context):
    source_bucket = event['bucket']
    source_key = unquote_plus(event['key'])
    execution_id = event['execution_id']
    if not source_key.startswith('raw/') or not source_key.lower().endswith('.pdf'):
        raise ValueError('Expected PDF under raw/')
    match = re.fullmatch(r'raw/([^/]+)/([^/]+)/(\d{4})/[^/]+\.pdf', source_key, re.I)
    if not match:
        raise ValueError('Expected raw/<election_type>/<state>/<year>/<file>.pdf')
    election_type, state, year = match.groups()
    csv_bucket = os.environ['RAW_CSV_BUCKET']
    processed_bucket = os.environ.get('PROCESSED_BUCKET', '')
    base = f'election_type={election_type}/state={state}/year={year}/run={execution_id}'
    with tempfile.TemporaryDirectory() as directory:
        pdf_path = Path(directory) / f'{year}.pdf'
        s3.download_file(source_bucket, source_key, str(pdf_path))
        raw = defaultdict(list)
        extract_pdf(pdf_path, raw)
        count = write_denormalized(raw, Path(directory))
        key = f'raw-csv/{base}/candidate_ballots.csv'
        s3.upload_file(str(Path(directory) / 'candidate_ballots.csv'), csv_bucket, key)
    return {'execution_id': execution_id, 'record_count': count,
            'csv_uri': f's3://{csv_bucket}/{key}',
            'cleaned_prefix': f's3://{os.environ["PROCESSED_BUCKET"]}/cleaned/{base}/',
            'warehouse_prefix': f's3://{os.environ["PROCESSED_BUCKET"]}/warehouse/{base}/'}
