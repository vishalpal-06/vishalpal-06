#!/usr/bin/env python3
"""Standalone ECI election PDF extractor: six core CSV datasets.
Usage: pip install pymupdf
       python final_election_extractor.py 1951.pdf 1957.pdf -o output
Reservation seat counts are populated only when unambiguous from source.
Blank cells mean unknown, not zero.
"""
from __future__ import annotations
import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
import fitz
INT = r"-?\d[\d,]*"
PARTY_GROUPS = {
    "NATIONAL PARTIES": "national",
    "STATE PARTIES": "state",
    "REGISTERED (UNRECOGNISED) PARTIES": "registered_unrecognised",
    "INDEPENDENTS": "independent",
}
SECTION_MARKERS = {
    "parties": "LIST OF PARTICIPATING POLITICAL PARTIES",
    "abbreviations": "OTHER ABBREVIATIONS AND DESCRIPTION",
    "highlights": "HIGHLIGHTS",
    "winners": "LIST OF SUCCESSFUL CANDIDATES",
    "party_performance": "PERFORMANCE OF POLITICAL PARTIES",
    "candidate_summary": "CANDIDATES DATA SUMMARY",
    "electors_summary": "ELECTORS DATA SUMMARY",
    "women": "WOMEN CANDIDATES",
    "constituency_summary": "CONSTITUENCY DATA - SUMMARY",
    "detailed": "DETAILED RESULTS",
}
TABLES = [
    "elections", "political_parties", "abbreviations", "highlights",
    "successful_candidates", "party_performance", "candidate_summary",
    "electors_summary", "women_candidates", "constituencies",
    "constituency_candidate_stats", "constituency_results", "candidate_results",
    "data_quality_issues", "source_files",
]
def clean(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()
def num(value: str | None):
    if value is None or value == "":
        return None
    try:
        return int(value.replace(",", ""))
    except ValueError:
        return None
def decimal(value: str | None):
    if value is None or value == "":
        return None
    try:
        return float(value.replace("%", ""))
    except ValueError:
        return None
def trailing_numbers(line: str) -> list[str]:
    return re.findall(r"(?\<![\w.])-?\d[\d,]*(?:**\.**\d+)?%?(?!\w)", line)
def section_of(text: str):
    head = "\n".join(text.splitlines()[:9]).upper()
    for section, marker in SECTION_MARKERS.items():
        if marker in head:
            return section
    return None
def append_issue(rows, election_id, code, message, page=None, section=None):
    rows["data_quality_issues"].append(dict(election_id=election_id, code=code,
        message=message, pdf_page=page, section=section))
def parse_parties(text, eid, page, rows):
    group = None
    for line in text.splitlines():
        s = clean(line)
        if s.upper() in PARTY_GROUPS:
            group = PARTY_GROUPS[s.upper()]
            continue
        m = re.match(r"^(\d+)\s***\.**\s*(\S+)\s{1,}(.+)$", line.strip())
        if m and group:
            rows["political_parties"].append(dict(election_id=eid, ordinal=num(m[1]),
                abbreviation=m[2], party_name=clean(m[3]), party_category=group,
                pdf_page=page))
def parse_abbreviations(text, eid, page, rows):
    for line in text.splitlines():
        m = re.match(r"^\s*([A-Za-z]{1,5})\s{3,}(.+?)\s*$", line)
        if m and m[1].upper() not in {"PARTY", "TOTAL"}:
            rows["abbreviations"].append(dict(election_id=eid,
                abbreviation=m[1], description=clean(m[2]), pdf_page=page))
def parse_highlights(text, eid, page, rows):
    labels = {
        "NO. OF CONSTITUENCIES": "constituencies_by_category",
        "TOTAL CONTESTANTS IN FRAY": "contestants_in_fray",
        "AVERAGE CONTESTANTS PER CONSTITUENCY": "avg_contestants",
        "MINIMUM CONTESTANTS IN A CONSTITUENCY": "min_contestants",
        "MAXIMUM CONTESTANTS IN A CONSTITUENCY": "max_contestants",
        "NO. OF ELECTORS ENTITLED TO VOTE": "electors_entitled_to_vote",
        "NO. OF ELECTORS WHO VOTED": "electors_who_voted",
        "NO. OF ELECTORS": "registered_electors",
        "POLLING PERCENTAGE": "polling_percentage",
        "NO. OF VALID VOTES": "valid_votes",
    }
    for line in text.splitlines():
        s = clean(line)
        for label, key in labels.items():
            if label in s.upper():
                tail = s.upper().split(label, 1)[1]
                values = trailing_numbers(tail)
                if values:
                    rows["highlights"].append(dict(election_id=eid, metric=key,
                        raw_value=clean(tail), numeric_value=decimal(values[0]), pdf_page=page))
                break
def parse_successful(text, eid, page, rows):
    current = None
    for line in text.splitlines():
        m = re.match(r"^\s*(\d+)**\.**\s+(.+?)\s{2,}(.+?)\s{2,}(\S+)\s*$", line)
        if m:
            current = num(m[1]); constituency = clean(m[2])
            rows["successful_candidates"].append(dict(election_id=eid,
                constituency_number=current, constituency_name=constituency,
                candidate_name=clean(m[3]), party=m[4], pdf_page=page))
            continue
        m = re.match(r"^\s{10,}(.+?)\s{2,}(\S+)\s*$", line)
        if current and m and m[2] not in {"PARTY", "WINNER"} and re.fullmatch(r"[A-Z][A-Z()]+", m[2]):
            rows["successful_candidates"].append(dict(election_id=eid,
                constituency_number=current, constituency_name=constituency,
                candidate_name=clean(m[1]), party=m[2], pdf_page=page))
def parse_party_performance(text, eid, page, rows):
    group = None
    retired_col = "RETIRED" in text.upper().split("NATIONAL PARTIES")[0]
    for line in text.splitlines():
        s = clean(line)
        if s.upper() in PARTY_GROUPS:
            group = PARTY_GROUPS[s.upper()]
            continue
        m = re.match(r"^\s*(\d+)\s***\.**\s*(\S+)\s+(.+)$", line)
        if not m or not group:
            continue
        # Use x positions / blank columns when retired is present; numeric token
        # count alone is ambiguous when optional RETIRED is blank.
        remainder = m[3]
        tokens = re.findall(r"\d+(?:**\.**\d+)?%?", remainder)
        if len(tokens) < 6:
            continue
        if retired_col:
            # right side always: won, FD, votes, vote %, contested vote %
            contested = num(tokens[0]); won, fd, votes = map(num, tokens[-5:-2])
            retired = num(tokens[1]) if len(tokens) >= 7 else None
            pct, contested_pct = map(decimal, tokens[-2:])
        else:
            contested, won, fd, votes = map(num, tokens[:4]); retired = None
            pct, contested_pct = map(decimal, tokens[4:6])
        rows["party_performance"].append(dict(election_id=eid, party=m[2],
            party_category=group, seats_contested=contested, retired=retired,
            seats_won=won, forfeited_deposits=fd, votes=votes,
            vote_pct=pct, vote_pct_contested=contested_pct, pdf_page=page))
def parse_candidate_summary(text, eid, page, rows):
    metric = None
    for line in text.splitlines():
        s = clean(line)
        m = re.match(r"^\d+**\.**\s+(NO**\.** OF CONSTITUENCIES|NOMINATIONS FILED|NOMINATIONS REJECTED|NOMINATIONS WITHDRAWN|CONTESTING CANDIDATES|FORFEITED DEPOSITS)", s, re.I)
        if m:
            metric = m[1].lower().replace(" ", "_").replace(".", "")
            if "NO. OF CONSTITUENCIES" in s.upper():
                values = trailing_numbers(s.split(m[1], 1)[-1])
                if len(values) >= 4:
                    for category, value in zip(("GEN", "SC", "ST", "TOTAL"), values[-4:]):
                        rows["candidate_summary"].append(dict(election_id=eid, metric=metric,
                            sex="all", category=category, value=decimal(value), pdf_page=page))
        elif metric and re.match(r"^[abc]**\.**\s*(Men|Women|Total)\b", s, re.I):
            sex = re.search(r"(Men|Women|Total)", s, re.I).group(1).lower()
            values = trailing_numbers(s.split(sex.title(), 1)[-1])
            if values:
                rows["candidate_summary"].append(dict(election_id=eid, metric=metric,
                    sex=sex, category="TOTAL", value=decimal(values[-1]), pdf_page=page))
def parse_electors_summary(text, eid, page, rows):
    metric = None
    for line in text.splitlines():
        s = clean(line)
        m = re.match(r"^\d+**\.**\s+(NO**\.** OF CONSTITUENCIES|ELECTORS WHO VOTED|ELECTORS|POLL PERCENTAGE|VALID VOTES)\b", s, re.I)
        if m:
            metric = m[1].lower().replace(" ", "_").replace(".", "")
            if metric in ("poll_percentage", "valid_votes"):
                values = trailing_numbers(s.split(m[1], 1)[-1])
                for cat, val in zip(("GEN", "SC", "ST", "TOTAL"), values[-4:]):
                    rows["electors_summary"].append(dict(election_id=eid, metric=metric,
                        seat_type="all", category=cat, value=decimal(val), pdf_page=page))
            continue
        if metric:
            m = re.match(r"^(Single Member|Double Member|Total)\s+(.+)$", s, re.I)
            if m:
                values = trailing_numbers(m[2])
                if len(values) >= 4:
                    for cat, val in zip(("GEN", "SC", "ST", "TOTAL"), values[-4:]):
                        rows["electors_summary"].append(dict(election_id=eid,
                            metric=metric, seat_type=m[1].lower().replace(" ", "_"),
                            category=cat, value=decimal(val), pdf_page=page))
def parse_women(text, eid, page, rows):
    current = None
    for line in text.splitlines():
        m = re.match(r"^\s*(\d+)\s*-\s*([A-Z][A-Z\s().-]+)\s*$", line)
        if m:
            current = (num(m[1]), clean(m[2])); continue
        m = re.match(r"^\s*(\d+)\s+(.+?)\s{2,}(\S+)\s+(\d+)\s+([\d.]+)\s+([WNF])\s+(\d+)\s+(\d+)\s+(\d+)\s*$", line)
        if current and m:
            rows["women_candidates"].append(dict(election_id=eid,
                constituency_number=current[0], constituency_name=current[1],
                rank=num(m[1]), candidate_name=clean(m[2]), party=m[3],
                votes=num(m[4]), vote_pct=decimal(m[5]), status=m[6],
                winner_votes=num(m[7]), margin_from_winner=num(m[8]),
                total_valid_votes=num(m[9]), pdf_page=page))
def parse_constituency_summary(text, eid, page, rows):
    m = re.search(r"CONSTITUENCY\s*:\s*(\d+)\s*-\s*(.*?)\s+NUMBER OF SEATS\s*:\s*(\d+)", text, re.I)
    if not m:
        return
    cid, name, seats = num(m[1]), clean(m[2]), num(m[3]); key = dict(election_id=eid, constituency_number=cid)
    electors = re.search(r"II**\.**\s*ELECTORS\s***\n**\s*1**\.**\s*TOTAL\s+(.+)", text, re.I)
    voters = re.search(r"III**\.**\s*ELECTORS WHO VOTED\s***\n**\s*1**\.**\s*TOTAL\s+(.+)", text, re.I)
    polled = re.search(r"IV**\.**\s*VOTES\s***\n**\s*1**\.**\s*POLLED\s+(\d+)", text, re.I)
    valid = re.search(r"2**\.**\s*VALID\s+(\d+)", text, re.I)
    margin = re.search(r"MARGIN\s*:\s*(-?\d+)(?:\s***\(**\s*(-?[\d.]+)%|\s+**\(**\s*(-?[\d.]+)%)?", text, re.I)
    dates = re.search(r"VI**\.**\s*DATES.*?**\n**\s*(\d{2}-\d{2}-\d{4})", text, re.I | re.S)
    def last(line):
        vals = trailing_numbers(line.group(1)) if line else []
        return num(vals[-1]) if vals else None
    rows["constituencies"].append(dict(**key, name=name, number_of_seats=seats,
        reservation="SC" if "(SC)" in name else "ST" if "(ST)" in name else "GEN",
        pdf_page=page))
    rows["constituency_results"].append(dict(**key, electors=last(electors),
        voters=last(voters), votes_polled=num(polled[1]) if polled else None,
        valid_votes=num(valid[1]) if valid else None,
        margin_votes=num(margin[1]) if margin else None,
        margin_pct=decimal((margin[2] or margin[3]) if margin else None),
        polling_date=dates[1] if dates else None, pdf_page=page))
    for line in text.splitlines():
        m = re.match(r"^\s*\d+**\.**\s*(NOMINATED|REJECTED|WITHDRAWN|CONTESTED|RETIRED|FORFEITED DEPOSIT)\s*(.*?)$", line, re.I)
        if m:
            values = trailing_numbers(m[2]); rows["constituency_candidate_stats"].append(dict(
                **key, metric=m[1].lower().replace(" ", "_"),
                male=num(values[0]) if len(values)>=3 else None,
                female=num(values[1]) if len(values)>=3 else None,
                total=num(values[-1]) if values else None, pdf_page=page))
def write_denormalized(raw, destination):
    destination.mkdir(parents=True, exist_ok=True)
    elections = {
        r["election_id"]: r
        for r in raw["elections"]
    }
    constituencies = {
        (r["election_id"], r["constituency_number"]): r
        for r in raw["constituencies"]
    }
    results = {
        (r["election_id"], r["constituency_number"]): r
        for r in raw["constituency_results"]
    }
    parties = {
        (r["election_id"], r["abbreviation"]): r
        for r in raw["political_parties"]
    }
    records = []
    for candidate in raw["candidate_results"]:
        election_id = candidate["election_id"]
        constituency_number = candidate["constituency_number"]
        key = (election_id, constituency_number)
        election = elections.get(election_id, {})
        constituency = constituencies.get(key, {})
        result = results.get(key, {})
        party = parties.get(
            (election_id, candidate["party"]), {}
        )
        records.append({
            "election_type": election.get("election_type"),
            "state": election.get("state"),
            "election_year": election.get("year"),
            "constituency_number": constituency_number,
            "constituency_name": candidate.get(
                "constituency_name"
            ),
            "reservation_type": constituency.get("reservation"),
            "number_of_seats": candidate.get("number_of_seats"),
            "candidate_name": candidate.get("candidate_name"),
            "gender": candidate.get("sex"),
            "party_code": candidate.get("party"),
            "party_name": party.get("party_name"),
            "party_category": party.get("party_category"),
            "votes": candidate.get("votes"),
            "vote_percentage": candidate.get("vote_pct"),
            "printed_serial": candidate.get("printed_serial"),
            "total_electors": result.get("electors"),
            "total_voters": result.get("voters"),
            "valid_votes": result.get("valid_votes"),
            "polling_date": result.get("polling_date"),
            "source_pdf_page": candidate.get("pdf_page"),
        })
    if not records:
        raise ValueError("No candidate records extracted from PDF")
    filepath = destination / "candidate_ballots.csv"
    with filepath.open(
        "w", newline="", encoding="utf-8-sig"
    ) as file:
        writer = csv.DictWriter(
            file, fieldnames=list(records[0])
        )
        writer.writeheader()
        writer.writerows(records)
    return len(records)
def parse_detailed(text, eid, page, rows, current=None):
    for line in text.splitlines():
        m = re.search(r"^\s*Constituency\s*:?\s*(\d+)\s+(.+?)\s+NUMBER OF SEATS\s*:?\s*(\d+)\s*$", line, re.I)
        if m:
            current = (num(m[1]), clean(m[2]), num(m[3])); continue
        if current is None:
            continue
        m = re.match(r"^\s*(\d+)\s***\.**\s*(.+?)\s+([MF])\s+(\S+)\s+(\d+)\s+([\d.]+%|#Num!)\s*$", line)
        if m:
            rows["candidate_results"].append(dict(election_id=eid,
                constituency_number=current[0], constituency_name=current[1],
                number_of_seats=current[2], printed_serial=num(m[1]),
                candidate_name=clean(m[2]), sex=m[3], party=m[4],
                votes=num(m[5]), vote_pct=decimal(m[6]) if m[6].endswith("%") else None, pdf_page=page))
            continue
        m = re.search(r"ELECTORS\s*:\s*(\d+)\s+VOTERS\s*:\s*(\d+)\s+POLL PERCENTAGE\s*:?\s*([\d.]+)%\s+VALID VOTES\s*:?\s*(\d+)", line, re.I)
        if m:
            # Store independently from summary, to allow source-to-source reconciliation.
            rows.setdefault("detailed_turnout", []).append(dict(election_id=eid,
                constituency_number=current[0], electors=num(m[1]), voters=num(m[2]),
                poll_pct=decimal(m[3]), valid_votes=num(m[4]), pdf_page=page))
    return current
def validate(eid, rows):
    detail = [r for r in rows["candidate_results"] if r["election_id"] == eid]
    summary = [r for r in rows["constituencies"] if r["election_id"] == eid]
    detail_groups = defaultdict(list)
    for r in detail:
        detail_groups[r["constituency_number"]].append(r)
    for r in summary:
        cid = r["constituency_number"]
        if cid not in detail_groups:
            append_issue(rows, eid, "MISSING_DETAIL", f"No detailed candidate rows for constituency {cid}", r["pdf_page"], "detailed")
    for r in [r for r in rows["constituency_results"] if r["election_id"] == eid]:
        cid = r["constituency_number"]
        votes = sum(x["votes"] for x in detail_groups[cid])
        if detail_groups[cid] and r["valid_votes"] is not None and votes != r["valid_votes"]:
            append_issue(rows, eid, "VOTE_TOTAL_MISMATCH", f"Constituency {cid}: detailed candidate votes={votes}, summary valid votes={r['valid_votes']}", r["pdf_page"], "constituency_summary")
    highlights = {r["metric"]: r["numeric_value"] for r in rows["highlights"] if r["election_id"] == eid}
    retired = sum((r["retired"] or 0) for r in rows["party_performance"] if r["election_id"] == eid)
    if highlights.get("contestants_in_fray") is not None and len(detail) + retired != highlights["contestants_in_fray"]:
        append_issue(rows, eid, "CANDIDATE_COUNT_MISMATCH", f"Detailed rows={len(detail)}, retired={retired}, Highlights contestants={highlights['contestants_in_fray']}", section="highlights")
    for r in detail:
        if r["vote_pct"] is None:
            append_issue(rows, eid, "INVALID_VOTE_PERCENTAGE", f"Candidate {r['candidate_name']} constituency {r['constituency_number']}: nonnumeric vote percentage", r["pdf_page"], "detailed")
def extract_pdf(path: Path, rows):
    doc = fitz.open(path)
    first = "\n".join(doc[i].get_text(sort=True) for i in range(min(3, len(doc))))
    y = re.search(r"GENERAL ELECTION,?\s*(19\d{2}|20\d{2})", first, re.I)
    year = int(y[1]) if y else int(re.search(r"\d{4}", path.stem)[0])
    eid = f"WB_ASSEMBLY_{year}"
    rows["elections"].append(dict(election_id=eid, year=year, state="West Bengal",
        election_type="Legislative Assembly", source_filename=path.name, pdf_pages=len(doc)))
    rows["source_files"].append(dict(election_id=eid, filename=path.name,
        pdf_pages=len(doc), parser_version="1.0"))
    counts = Counter()
    detailed_started = False
    detailed_current = None
    for index, page in enumerate(doc):
        text = page.get_text(sort=True)
        section = section_of(text)
        if section == "detailed":
            detailed_started = True
        if not section and detailed_started:
            section = "detailed"
        if not section:
            # Section continuation pages have report footer; detailed results can have no heading.
            foot = re.search(r"rpt([A-Za-z]+)\s*-\s*Page", text)
            if foot:
                footer = foot[1].lower()
                for token, candidate in (("listofparticipating", "parties"),
                    ("listsuccessful", "winners"), ("womencandidates", "women"),
                    ("constituencysummary", "constituency_summary")):
                    if token in footer:
                        section = candidate; break
            if not section and "Constituency" in text and "NUMBER OF SEATS" in text and "ELECTORS" in text:
                section = "detailed"
        if not section:
            continue
        counts[section] += 1
        parser = {
            "parties": parse_parties, "abbreviations": parse_abbreviations,
            "highlights": parse_highlights, "winners": parse_successful,
            "party_performance": parse_party_performance,
            "candidate_summary": parse_candidate_summary,
            "electors_summary": parse_electors_summary,
            "women": parse_women, "constituency_summary": parse_constituency_summary,
            "detailed": parse_detailed,
        }.get(section)
        if parser:
            if section == "detailed":
                detailed_current = parser(text, eid, index + 1, rows, detailed_current)
            else:
                parser(text, eid, index + 1, rows)
    validate(eid, rows)
    return eid, dict(counts)
def write_csvs(rows, output):
    output.mkdir(parents=True, exist_ok=True)
    for table in TABLES + ["detailed_turnout"]:
        records = rows.get(table, [])
        if not records:
            continue
        fields = list(dict.fromkeys(k for record in records for k in record))
        with (output / f"{table}.csv").open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader(); writer.writerows(records)
TABLES = ('elections', 'parties', 'constituencies', 'candidates', 'candidate_results', 'election_results')
def norm(s):
    return re.sub(r'[^A-Z0-9]', '', (s or '').upper())
def build_core(raw):
    out = {name: [] for name in TABLES}
    out['elections'] = []
    for r in raw['elections']:
        eid = r['election_id']
        stats = {v['metric']: v['numeric_value'] for v in raw['highlights'] if v['election_id'] == eid}
        cs = [c for c in raw['constituencies'] if c['election_id'] == eid]
        out['elections'].append(dict(**r,
            total_constituencies=len(cs), total_seats=sum(c['number_of_seats'] for c in cs),
            total_candidates=stats.get('contestants_in_fray'),
            total_electors=stats.get('registered_electors'),
            electors_entitled_to_vote=stats.get('electors_entitled_to_vote'),
            total_voters=stats.get('electors_who_voted'),
            overall_turnout_pct=(round(100*stats['electors_who_voted']/stats['electors_entitled_to_vote'], 2) if stats.get('electors_who_voted') is not None and stats.get('electors_entitled_to_vote') else None),
            total_valid_votes=stats.get('valid_votes')))
    perf = {(r['election_id'], r['party']): r for r in raw['party_performance']}
    for p in raw['political_parties']:
        x = perf.get((p['election_id'], p['abbreviation']), {})
        out['parties'].append(dict(election_id=p['election_id'], party_code=p['abbreviation'], party_name=p['party_name'], party_type=p['party_category'], seats_contested=x.get('seats_contested'), seats_won=x.get('seats_won'), retired=x.get('retired'), forfeited_deposits=x.get('forfeited_deposits'), total_votes=x.get('votes'), vote_percentage=x.get('vote_pct'), contested_seats_vote_percentage=x.get('vote_pct_contested')))
    summary = {(r['election_id'], r['constituency_number']): r for r in raw['constituency_results']}
    turnout = {(r['election_id'], r['constituency_number']): r for r in raw['detailed_turnout']}
    for c in raw['constituencies']:
        eid, cid = c['election_id'], c['constituency_number']
        key = f'{eid}_{cid:03d}'
        # A (SC)/(ST) double-member constituency normally combines one reserved
        # and one general seat. Keep counts nullable when the PDF does not
        # explicitly identify the composition; avoid false certainty.
        reservation = c['reservation']
        seats = c['number_of_seats']
        seat_counts = {'general_seats': None, 'sc_reserved_seats': None, 'st_reserved_seats': None}
        if seats == 1:
            seat_counts = dict(general_seats=int(reservation == 'GEN'),
                               sc_reserved_seats=int(reservation == 'SC'),
                               st_reserved_seats=int(reservation == 'ST'))
        elif seats == 2 and reservation == 'GEN':
            seat_counts = dict(general_seats=2, sc_reserved_seats=0, st_reserved_seats=0)
        out['constituencies'].append(dict(constituency_id=key, election_id=eid,
            constituency_number=cid, constituency_name=c['name'],
            reservation_type=reservation, number_of_seats=seats,
            **seat_counts, reserved_seat_count=(sum(seat_counts[k] for k in ('sc_reserved_seats','st_reserved_seats')) if seat_counts['sc_reserved_seats'] is not None else None)))
        s, d = summary.get((eid,cid), {}), turnout.get((eid,cid), {})
        electors = s.get('electors') if s.get('electors') is not None else d.get('electors')
        voters = s.get('voters') if s.get('voters') is not None else d.get('voters')
        valid = s.get('valid_votes') if s.get('valid_votes') is not None else d.get('valid_votes')
        out['election_results'].append(dict(constituency_id=key, election_id=eid,
            total_electors=electors, total_voters=voters, votes_polled=s.get('votes_polled'),
            valid_votes=valid, poll_percentage=d.get('poll_pct'),
            victory_margin=s.get('margin_votes'), margin_percentage=s.get('margin_pct'),
            polling_date=s.get('polling_date'), is_uncontested=s.get('is_uncontested')))
    winners = defaultdict(list)
    for w in raw['successful_candidates']:
        winners[(w['election_id'], w['constituency_number'])].append(w)
    # Candidate identity is an election-specific nomination; identical names across years
    # are NOT automatically assumed to identify the same person.
    for r in raw['candidate_results']:
        eid, cid = r['election_id'], r['constituency_number']
        candidate_id = f'{eid}_{cid:03d}_{r["printed_serial"]:03d}'
        matched = [w for w in winners[(eid,cid)] if norm(w['candidate_name']) == norm(r['candidate_name']) and w['party'] == r['party']]
        # NULL when winners list could not be parsed for the constituency.
        is_winner = bool(matched) if winners[(eid,cid)] else None
        cat = re.search(r'**\(**(SC|ST)**\)**', r['candidate_name'], re.I)
        out['candidates'].append(dict(candidate_id=candidate_id, election_id=eid,
            constituency_id=f'{eid}_{cid:03d}', candidate_name=r['candidate_name'],
            gender=r['sex'], candidate_category=cat.group(1).upper() if cat else None,
            party_code=r['party']))
        out['candidate_results'].append(dict(candidate_id=candidate_id, election_id=eid,
            constituency_id=f'{eid}_{cid:03d}', votes=r['votes'], vote_percentage=r['vote_pct'],
            printed_serial=r['printed_serial'], rank=None, is_winner=is_winner,
            elected_seat_category=None, deposit_forfeited=None,
            source_pdf_page=r['pdf_page']))
    by_constituency = defaultdict(list)
    for r in out['candidate_results']:
        by_constituency[r['constituency_id']].append(r)
    for group in by_constituency.values():
        ordered = sorted(group, key=lambda r: (-r['votes'], r['printed_serial']))
        for rank, record in enumerate(ordered, 1):
            record['rank'] = rank
    return out
def write_csvs(out, destination):
    destination.mkdir(parents=True, exist_ok=True)
    for name in TABLES:
        records = out[name]
        if not records:
            continue
        with (destination / f'{name}.csv').open('w', newline='', encoding='utf-8-sig') as fh:
            writer = csv.DictWriter(fh, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(records)
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('pdfs', nargs='+', type=Path)
    ap.add_argument('--output', '-o', type=Path, default=Path('core_csv'))
    args = ap.parse_args()
    raw = defaultdict(list)
    for pdf in args.pdfs:
        eid, _ = extract_pdf(pdf, raw)
        # Read winner labels directly from constituency summary pages as a
        # fallback when the successful-candidates listing wraps across lines.
        with fitz.open(pdf) as doc:
            for page in doc:
                t = page.get_text(sort=True)
                m = re.search(r'CONSTITUENCY\s*:\s*(\d+)\s*-', t, re.I)
                if not m or 'CONSTITUENCY DATA - SUMMARY' not in t:
                    continue
                cid = int(m.group(1))
                if 'Uncontested' in t or 'Returned Uncontested' in t:
                    for result in raw['constituency_results']:
                        if result['election_id'] == eid and result['constituency_number'] == cid:
                            result['is_uncontested'] = True
                for line in t.splitlines():
                    w = re.match(r'^\s*Winner(?:\s+[12])?\s+([A-Z][A-Z()]+)\s{2,}(.+?)\s{2,}\d+\s*$', line, re.I)
                    if w:
                        raw['successful_candidates'].append(dict(election_id=eid, constituency_number=cid, candidate_name=w.group(2).strip(), party=w.group(1)))
    total = write_denormalized(raw, args.output)
    summary = {"candidate_ballots": total}
    print(json.dumps(summary, indent=2))
    # Only six CSV datasets are generated; no auxiliary CSV or JSON output.
if __name__ == "__main__":
    main()
