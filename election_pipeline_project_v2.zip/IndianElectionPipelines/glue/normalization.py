import sys
import time
import boto3
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession, functions as F

args = getResolvedOptions(sys.argv,['JOB_NAME','INPUT_PREFIX','OUTPUT_PREFIX','EXECUTION_ID',
 'REDSHIFT_WORKGROUP','REDSHIFT_DATABASE','REDSHIFT_ROLE_ARN'])
spark = SparkSession.builder.getOrCreate()
df = spark.read.parquet(args['INPUT_PREFIX'])
election_key = ['election_type','state','election_year']
const_key = election_key + ['constituency_number']
candidate_key = const_key + ['printed_serial']
datasets = {
 'elections': df.select(*election_key).distinct(),
 'constituencies': df.select(*const_key,'constituency_name','reservation_type','number_of_seats').dropDuplicates(const_key),
 'parties': df.select(*election_key,'party_code','party_name','party_category').dropDuplicates(election_key+['party_code']),
 'candidates': df.select(*candidate_key,'candidate_name','gender','party_code').dropDuplicates(candidate_key),
 'candidate_results': df.select(*candidate_key,'votes','vote_percentage','total_electors','total_voters','valid_votes','polling_date','source_pdf_page')
}
for name, dataset in datasets.items():
    dataset.coalesce(1).write.mode('overwrite').parquet(args['OUTPUT_PREFIX']+name+'/')

# Execute Redshift Data API statements synchronously. Each run replaces its own election
# scope via delete+insert in one transaction (COPY into temporary staging tables).
client=boto3.client('redshift-data')
workgroup=args['REDSHIFT_WORKGROUP']; database=args['REDSHIFT_DATABASE']; role=args['REDSHIFT_ROLE_ARN']

def sql(statement):
    response=client.execute_statement(WorkgroupName=workgroup,Database=database,Sql=statement)
    identifier=response['Id']
    while True:
        status=client.describe_statement(Id=identifier)
        if status['Status'] in ('FAILED','ABORTED'):
            raise RuntimeError(status.get('Error','Redshift statement failed'))
        if status['Status']=='FINISHED':
            return
        time.sleep(2)

sql('CREATE SCHEMA IF NOT EXISTS analytics')
# Table grain and column definitions deliberately align with the candidate-level source.
tables={
 'elections': 'election_type VARCHAR(100), state VARCHAR(100), election_year BIGINT',
 'constituencies': 'election_type VARCHAR(100), state VARCHAR(100), election_year BIGINT, constituency_number BIGINT, constituency_name VARCHAR(512), reservation_type VARCHAR(50), number_of_seats BIGINT',
 'parties': 'election_type VARCHAR(100), state VARCHAR(100), election_year BIGINT, party_code VARCHAR(100), party_name VARCHAR(512), party_category VARCHAR(100)',
 'candidates': 'election_type VARCHAR(100), state VARCHAR(100), election_year BIGINT, constituency_number BIGINT, printed_serial BIGINT, candidate_name VARCHAR(512), gender VARCHAR(10), party_code VARCHAR(100)',
 'candidate_results': 'election_type VARCHAR(100), state VARCHAR(100), election_year BIGINT, constituency_number BIGINT, printed_serial BIGINT, votes BIGINT, vote_percentage DOUBLE PRECISION, total_electors BIGINT, total_voters BIGINT, valid_votes BIGINT, polling_date DATE, source_pdf_page BIGINT'
}
# Redshift COPY accepts Parquet directly from S3. Use temporary staging and atomic replacement.
for name, definition in tables.items():
    sql(f'CREATE TABLE IF NOT EXISTS analytics.{name} ({definition})')
    path=args['OUTPUT_PREFIX']+name+'/'
    # BatchExecuteStatement runs its statements in one transaction.
    statement=f'''BEGIN;
CREATE TEMP TABLE incoming (LIKE analytics.{name});
COPY incoming FROM '{path}' IAM_ROLE '{role}' FORMAT AS PARQUET;
DELETE FROM analytics.{name} USING (SELECT DISTINCT election_type, state, election_year FROM incoming) src
WHERE analytics.{name}.election_type=src.election_type AND analytics.{name}.state=src.state AND analytics.{name}.election_year=src.election_year;
INSERT INTO analytics.{name} SELECT * FROM incoming;
DROP TABLE incoming;
COMMIT;'''
    statements=[line.strip() for line in statement.split(';') if line.strip() and line.strip().upper() not in ('BEGIN','COMMIT')]
    response=client.batch_execute_statement(WorkgroupName=workgroup,Database=database,Sqls=statements)
    identifier=response['Id']
    while True:
        status=client.describe_statement(Id=identifier)
        if status['Status'] in ('FAILED','ABORTED'):
            raise RuntimeError(status.get('Error','Redshift batch failed'))
        if status['Status']=='FINISHED':
            break
        time.sleep(2)
print('Loaded five analytical tables for execution',args['EXECUTION_ID'])
