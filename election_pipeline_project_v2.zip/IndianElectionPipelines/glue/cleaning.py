import sys
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession, functions as F, types as T

args = getResolvedOptions(sys.argv, ['JOB_NAME', 'INPUT_URI', 'OUTPUT_PREFIX', 'EXECUTION_ID'])
spark = SparkSession.builder.getOrCreate()
columns = ['election_type','state','election_year','constituency_number','constituency_name',
 'reservation_type','number_of_seats','candidate_name','gender','party_code','party_name',
 'party_category','votes','vote_percentage','printed_serial','total_electors','total_voters',
 'valid_votes','polling_date','source_pdf_page']
raw_schema = T.StructType([T.StructField(c, T.StringType(), True) for c in columns])
df = spark.read.option('header',True).option('mode','FAILFAST').schema(raw_schema).csv(args['INPUT_URI'])
for c in columns:
    df = df.withColumn(c, F.when(F.trim(F.col(c)) == '', None).otherwise(F.trim(F.col(c))))
for c in ['election_year','constituency_number','number_of_seats','votes','printed_serial',
          'total_electors','total_voters','valid_votes','source_pdf_page']:
    df = df.withColumn(c, F.regexp_replace(F.col(c), ',', '').cast('long'))
df = df.withColumn('vote_percentage',F.regexp_replace('vote_percentage','%','').cast('double'))
df = df.withColumn('polling_date', F.to_date('polling_date','dd-MM-yyyy'))
key = ['election_type','state','election_year','constituency_number','printed_serial']
duplicates = df.groupBy(*key).count().where('count > 1').select(*key).withColumn('duplicate',F.lit(True))
df = df.join(duplicates,key,'left')
invalid = (F.col('election_year').isNull() | F.col('constituency_number').isNull() |
 F.col('candidate_name').isNull() | F.col('printed_serial').isNull() | F.col('votes').isNull() |
 (F.col('votes') < 0) | (F.col('number_of_seats') < 1) |
 (F.col('vote_percentage').isNotNull() & ~F.col('vote_percentage').between(0,100)) |
 F.coalesce(F.col('duplicate'),F.lit(False)))
rejected = df.where(invalid).withColumn('rejection_reason',F.lit('missing/invalid fields or duplicate key'))
rejected.drop('duplicate').write.mode('overwrite').parquet(args['OUTPUT_PREFIX'].replace('/cleaned/','/rejected/'))
clean = df.where(~invalid).drop('duplicate')
if clean.limit(1).count() == 0:
    raise ValueError('No valid candidate records')
clean.coalesce(1).write.mode('overwrite').parquet(args['OUTPUT_PREFIX'])
print(f'cleaned rows={clean.count()} rejected rows={rejected.count()} execution={args["EXECUTION_ID"]}')
