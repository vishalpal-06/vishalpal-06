# Election PDF extraction pipeline (AWS CDK Python)

## Architecture

S3 ObjectCreated -> SQS queue -> Docker-image Lambda (PyMuPDF extractor) -> destination S3. SQS retries failures 3 times and sends persistent failures to a DLQ. All buckets are private, encrypted and versioned; retained on stack deletion.

## Raw input paths

```
raw/assembly/west_bengal/1951/report.pdf
raw/assembly/west_bengal/1957/report.pdf
```

Upload with `aws s3 cp 1957.pdf s3://<raw-bucket>/raw/assembly/west_bengal/1957/report.pdf`.

## Processed output paths

```
datasets/elections/election_type=assembly/state=west_bengal/year=1957/data.csv
datasets/parties/election_type=assembly/state=west_bengal/year=1957/data.csv
datasets/constituencies/election_type=assembly/state=west_bengal/year=1957/data.csv
datasets/candidates/election_type=assembly/state=west_bengal/year=1957/data.csv
datasets/candidate_results/election_type=assembly/state=west_bengal/year=1957/data.csv
datasets/election_results/election_type=assembly/state=west_bengal/year=1957/data.csv
```

This **dataset-first** layout is easier to catalog as six Athena/Glue tables than a year-first layout. Each election overwrites its six deterministic output keys; bucket versioning preserves prior versions. S3/SQS can deliver events more than once; overwriting fixed keys is intentional. For production-quality atomic publication, use a manifest/commit marker and stage outputs before publishing.

## Deploy

Requires Python 3.12+, Docker, AWS credentials and AWS CDK CLI (`npm install -g aws-cdk`).

```
python -m pip install -r requirements.txt
cdk bootstrap aws://ACCOUNT_ID/ap-south-1
cdk deploy -c account=ACCOUNT_ID -c region=ap-south-1
```

Upload PDFs only under `raw/assembly/west_bengal/<year>/`. The current parser is **only validated** for West Bengal Assembly 1951 and 1957 PDFs. Adding new states/years requires testing parser compatibility. No Athena catalog resources are provisioned; partitions are merely arranged to support future Athena/Glue integration.

## Operations

Monitor Lambda CloudWatch logs, SQS queue depth, and DLQ. Lambda is limited to 15 minutes, 4 GB `/tmp`, and 30 MB PDF size by application check. 90-minute SQS visibility timeout is >= 6x Lambda timeout. Concurrency capped at two. Invalid files will be retried and land in DLQ. The input path must agree with the year/type/state extracted from the PDF cover.
