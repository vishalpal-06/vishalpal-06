from aws_cdk import (
    Stack, Duration, RemovalPolicy, CfnOutput, Size,
    aws_s3 as s3, aws_s3_notifications as notifications,
    aws_lambda as lambda_, aws_sqs as sqs,
    aws_lambda_event_sources as event_sources,
    aws_logs as logs,
)
from constructs import Construct


class ElectionPipelineStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        raw = s3.Bucket(self, "RawElectionReports",
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            enforce_ssl=True, encryption=s3.BucketEncryption.S3_MANAGED,
            versioned=True, removal_policy=RemovalPolicy.RETAIN)
        processed = s3.Bucket(self, "ProcessedElectionData",
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            enforce_ssl=True, encryption=s3.BucketEncryption.S3_MANAGED,
            versioned=True, removal_policy=RemovalPolicy.RETAIN)

        dlq = sqs.Queue(self, "PdfProcessingDLQ",
            retention_period=Duration.days(14),
            encryption=sqs.QueueEncryption.SQS_MANAGED)
        queue = sqs.Queue(self, "PdfProcessingQueue",
            visibility_timeout=Duration.minutes(90),
            retention_period=Duration.days(4),
            dead_letter_queue=sqs.DeadLetterQueue(queue=dlq, max_receive_count=3),
            encryption=sqs.QueueEncryption.SQS_MANAGED)

        worker = lambda_.DockerImageFunction(self, "ElectionPdfWorker",
            code=lambda_.DockerImageCode.from_image_asset("lambda"),
            architecture=lambda_.Architecture.X86_64,
            memory_size=2048,
            ephemeral_storage_size=Size.mebibytes(4096),
            timeout=Duration.minutes(15),
            reserved_concurrent_executions=2,
            environment={
                "DESTINATION_BUCKET": processed.bucket_name,
                "SOURCE_PREFIX": "raw/",
                "MAX_PDF_BYTES": str(30 * 1024 * 1024),
            },
            log_retention=logs.RetentionDays.ONE_MONTH)
        raw.grant_read(worker)
        processed.grant_put(worker)
        worker.add_event_source(event_sources.SqsEventSource(
            queue, batch_size=1, report_batch_item_failures=True,
            max_concurrency=2))

        raw.add_event_notification(s3.EventType.OBJECT_CREATED,
            notifications.SqsDestination(queue),
            s3.NotificationKeyFilter(prefix="raw/", suffix=".pdf"))

        CfnOutput(self, "RawBucket", value=raw.bucket_name)
        CfnOutput(self, "ProcessedBucket", value=processed.bucket_name)
        CfnOutput(self, "ProcessingQueueUrl", value=queue.queue_url)
        CfnOutput(self, "DeadLetterQueueUrl", value=dlq.queue_url)
