"""S3 -> SQS -> Lambda -> partitioned dataset-first S3 CSV outputs."""
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import unquote_plus

import boto3
import fitz

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
S3 = boto3.client("s3")
DATASETS = ("elections", "parties", "constituencies", "candidates",
            "candidate_results", "election_results")


def get_metadata(pdf: Path) -> tuple[str, str, str]:
    with fitz.open(pdf) as document:
        cover = "\n".join(document[i].get_text(sort=True) for i in range(min(3, len(document))))
    year = re.search(r"GENERAL\s+ELECTION\s*,?\s*(19\d{2}|20\d{2})", cover, re.I)
    if not year:
        raise ValueError("Could not detect election year from PDF")
    if "LEGISLATIVE ASSEMBLY" not in cover.upper():
        raise ValueError("Current parser only supports Assembly elections")
    if "WEST BENGAL" not in cover.upper():
        raise ValueError("Current parser only validated for West Bengal")
    return "assembly", "west_bengal", year.group(1)


def process_pdf(bucket: str, key: str) -> dict:
    if not key.startswith(os.environ.get("SOURCE_PREFIX", "raw/")) or not key.lower().endswith(".pdf"):
        return {"skipped": key}
    head = S3.head_object(Bucket=bucket, Key=key)
    max_bytes = int(os.environ.get("MAX_PDF_BYTES", str(30 * 1024 * 1024)))
    if head["ContentLength"] > max_bytes:
        raise ValueError(f"PDF exceeds size limit: {key}")

    with tempfile.TemporaryDirectory(dir="/tmp") as tmp:
        source = Path(tmp) / "input.pdf"
        output = Path(tmp) / "output"
        S3.download_file(bucket, key, str(source))
        election_type, state, year = get_metadata(source)
        # Raw key is the canonical source identity. Reject misfiled documents.
        expected = f"raw/{election_type}/{state}/{year}/"
        if not key.startswith(expected):
            raise ValueError(f"Unexpected S3 path {key!r}; expected prefix {expected!r}")
        cmd = [sys.executable, str(Path(__file__).with_name("final_election_extractor.py")),
               str(source), "--output", str(output)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=800, check=True)
        LOG.info("Extraction: %s", result.stdout[-3000:])

        # Validate all six before writing any S3 objects.
        paths = {name: output / f"{name}.csv" for name in DATASETS}
        missing = [name for name, path in paths.items() if not path.is_file() or path.stat().st_size == 0]
        if missing:
            raise RuntimeError(f"Missing/empty datasets: {missing}")
        target = os.environ["DESTINATION_BUCKET"]
        keys = []
        for name, path in paths.items():
            # Dataset-first Hive-style partitioning for Athena/Glue.
            destination_key = (f"datasets/{name}/election_type={election_type}/"
                               f"state={state}/year={year}/data.csv")
            S3.upload_file(str(path), target, destination_key,
                           ExtraArgs={"ContentType": "text/csv; charset=utf-8"})
            keys.append(destination_key)
        return {"source": f"s3://{bucket}/{key}", "output_keys": keys}


def lambda_handler(event, context):
    failed = []
    for message in event.get("Records", []):
        try:
            payload = json.loads(message["body"])
            # Native S3 notifications arrive directly as SQS message bodies.
            if payload.get("Event") == "s3:TestEvent":
                continue
            for record in payload.get("Records", []):
                if record.get("eventSource") != "aws:s3":
                    continue
                bucket = record["s3"]["bucket"]["name"]
                key = unquote_plus(record["s3"]["object"]["key"])
                LOG.info("Processing s3://%s/%s", bucket, key)
                LOG.info("Result: %s", process_pdf(bucket, key))
        except Exception:
            LOG.exception("Failed to process SQS message %s", message.get("messageId"))
            failed.append({"itemIdentifier": message["messageId"]})
    return {"batchItemFailures": failed}
