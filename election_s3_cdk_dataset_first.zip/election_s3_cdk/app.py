#!/usr/bin/env python3
import aws_cdk as cdk
from stack import ElectionPipelineStack

app = cdk.App()
ElectionPipelineStack(app, "ElectionPdfPipelineStack", env=cdk.Environment(
    account=app.node.try_get_context("account"),
    region=app.node.try_get_context("region") or "ap-south-1",
))
app.synth()
