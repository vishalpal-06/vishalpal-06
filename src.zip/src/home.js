import React, { Component } from 'react';
import Card from './card';
import axios from 'axios';


class Home extends Component {
    state = {
        movies: []
    }

    componentDidMount() {
        axios.get('https://api.themoviedb.org/3/movie/popular?api_key=9ff7745e151c5e2ce4d758589c85f0fe&language=en-US&page=1')
        .then(response => {
            this.setState({ movies: response.data.results });
            console.log(this.state.movies);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
    }

    render() {
        return (
            <div>
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-4">Welcome to Movie Page</h1>
                        <p class="lead">Discover trending movies, top-rated films, and explore details using TMDb API integration. This project is built for learning and exploring movie data.</p>
                        <br />
                        <input type="text" class="form-control" placeholder="Search..." />
                        <button class="btn btn-dark mt-2">Search</button>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            Top Movies
                        </div>
                        <div class="row">
                            {
                                this.state.movies.map(function(movie, index){
                                    return <div class="col-3">
                                        <Card name={movie.title} overview={movie.overview} imageurl={movie.poster_path}/>
                                    </div>
                                })
                            }
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Home;