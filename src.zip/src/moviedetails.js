import React, { Component } from 'react';

class MovieDetails extends Component {
    state = {  } 
    render() { 
        return (
            <h1>MovieDetails</h1>
        );
    }
}
 
export default MovieDetails;