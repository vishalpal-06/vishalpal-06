import React,{Component} from 'react';
import Navbar from './navbar';
import Home from './home';

class App extends Component{
  
  state = {};

  render() {
    return (
      <div>
        <Navbar />
        <Home />
      </div>
    );
  }
}

export default App;