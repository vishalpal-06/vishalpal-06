import React, { Component } from 'react';

class Card extends Component {
    render() {
        return (
            <div className="card d-flex flex-column justify-content-between " style={{ margin: "10px", height: "630px", width: "100%" }}>
                <img
                    className="card-img-top"
                    src={"https://image.tmdb.org/t/p/w500" + this.props.imageurl}
                    alt="Card image cap"
                    style={{ height: "350px", objectFit: "cover" }}
                />
                <div className="card-body d-flex flex-column">
                    <h5 className="card-title">{this.props.name}</h5>
                    <p className="card-text flex-grow-1">
                        {this.props.overview.split(' ').slice(0, 25).join(' ') + "..."}
                    </p>
                    <a href="#" className="btn btn-dark mt-auto">View Details</a>
                </div>
            </div>
        );
    }
}

export default Card;
